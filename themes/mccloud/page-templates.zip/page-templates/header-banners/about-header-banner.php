<?php
set_query_var('heroCustomHtml', "
      <div class='flex gap-3 justify-center'>
                <img src='/wp-content/themes/mccloud/image/partner.png' alt='' class='w-[100px]'>
                <img src='/wp-content/themes/mccloud/image/education-partner.png' alt='' class='w-[130px]'>
                <img src='/wp-content/themes/mccloud/image/cloud.png' alt='' class='w-[100px]'>
            </div>
");

require get_template_directory() . '/template-parts/common/heroSection.php';