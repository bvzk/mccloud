<?php
set_query_var('heroLabel', 'Google Workspace');
set_query_var('heroTitle', 'Google Workspace Business:<br>перший крок до трансформації вашого бізнесу');
set_query_var('heroSubtitle', 'Google Workspace забезпечує надійне хмарне рішення, яке дає змогу вашій компанії працювати будь-де, будь-коли, з упевненістю в безпеці даних і доступом до спільної роботи в режимі реального часу.');
set_query_var('heroPicture', "
     <picture>
                <source type='image/webp'
                    srcset='/wp-content/themes/mccloud/image/business-header-banner-m.webp, /wp-content/themes/mccloud/image/business-header-banner-m-2x.webp 2x'
                    media='(max-width: 768px)'>
                <source type='image/webp'
                    srcset='/wp-content/themes/mccloud/image/business-header-banner.webp, /wp-content/themes/mccloud/image/business-header-banner-2x.webp 2x'
                    media='(min-width: 769px)'>
                <source type='image/webp'
                    srcset='/wp-content/themes/mccloud/image/business-header-banner.webp, /wp-content/themes/mccloud/image/business-header-banner-2x.webp 2x'>
                <source
                    srcset='/wp-content/themes/mccloud/image/business-header-banner-m.png, /wp-content/themes/mccloud/image/business-header-banner-m-2x.png 2x'
                    media='(max-width: 768px)'>
                <source
                    srcset='/wp-content/themes/mccloud/image/business-header-banner.png, /wp-content/themes/mccloud/image/business-header-banner-2x.png 2x'
                    media='(min-width: 769px)'>
                <img width='566' height='540' src='/wp-content/themes/mccloud/image/business-header-banner.png'
                    alt='Business'>
            </picture>
            ");

require get_template_directory() . '/template-parts/common/heroSection.php';