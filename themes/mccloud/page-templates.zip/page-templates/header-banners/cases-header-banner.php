<div class="max-w-[806px] mx-auto pb-[85px] pt-[54px] 2xl:py-[120px] text-center">
    <!--   <nav aria-label="Breadcrumb" class="mb-[18px]">
        <ul class="flex text-[#8E8E93] justify-center text-[14px]">
            <li><a href="<?= home_url(); ?>" class="text-[#8E8E93]">Головна</a></li>
            <li><span class="mx-2 inline-block mx-2">/</span></li>
            <?php if (is_page('cases') && isset($_GET['term_id']) && $category = get_category_by_slug($_GET['term_id'])) { ?>
                <li><a href="<?= get_permalink(1147); ?>" class="text-[#8E8E93]"><?php the_title(); ?></a></li>
                <li><span class="mx-2 inline-block mx-2">/</span></li>
                <li class="truncate"><span aria-current="page"><?= $category->name; ?></span></li>
            <?php } else { ?>
                <li class="truncate"><span aria-current="page"><?php the_title(); ?></span></li>
            <?php } ?>
        </ul>
    </nav> -->
    <h1 class="mb-4"><?php
    if (is_page('cases') && isset($_GET['term_id']) && $category = get_category_by_slug($_GET['term_id'])) {
        echo "Кейси для яких використали пакети " . $category->name;
    } else {
        echo "Наші Кейси";
    }
    ?></h1>
    <div class="text-[20px] leading-[28px] font-medium">
        Оптимізуйте свої бізнес-процеси з Google Workspace: <br>
        Підвищуйте продуктивність і співпрацю.
    </div>
</div>