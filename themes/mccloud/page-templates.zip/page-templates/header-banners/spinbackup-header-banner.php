<?php
set_query_var('heroLabel', 'Spinbackup');
set_query_var('heroTitle', 'Spinbackup: захист даних та резервне копіювання для Google Workspace');
set_query_var('heroSubtitle', "
                Spinbackup виконує резервне копіювання (backup) даних у Google Workspace, забезпечуючи захист даних Google Workspace від втрати, безпеку аварійне відновлення для користувачів хмарних послуг. Платформа пропонує захист від кіберзагроз та виявлення зловмисних програм, тому є цінним інструментом для клієнтів, які цінують безпеку своїх даних у хмарних середовищах.
");
set_query_var('heroPicture', "
  <picture>
                <source type='image/webp' srcset='/wp-content/themes/mccloud/image/spinbackup-header-banner-m.webp, /wp-content/themes/mccloud/image/spinbackup-header-banner-m-2x.webp 2x' media='(max-width: 768px)'>
                <source type='image/webp' srcset='/wp-content/themes/mccloud/image/spinbackup-header-banner.webp, /wp-content/themes/mccloud/image/spinbackup-header-banner-2x.webp 2x' media='(min-width: 769px)'>
                <source type='image/webp' srcset='/wp-content/themes/mccloud/image/spinbackup-header-banner.webp, /wp-content/themes/mccloud/image/spinbackup-header-banner-2x.webp 2x'>
                <source srcset='/wp-content/themes/mccloud/image/spinbackup-header-banner-m.png, /wp-content/themes/mccloud/image/spinbackup-header-banner-m-2x.png 2x' media='(max-width: 768px)'>
                <source srcset='/wp-content/themes/mccloud/image/spinbackup-header-banner.png, /wp-content/themes/mccloud/image/spinbackup-header-banner-2x.png 2x' media='(min-width: 769px)'>
                <img width='566' height='540' src='/wp-content/themes/mccloud/image/spinbackup-header-banner.png' alt='Enterprise'>
            </picture>
            ");
set_query_var('heroCustomHtml', "
          <div class='flex gap-3 flex-col md:flex-row'>
                <a href='#consultForm' class='btn btn-customLightGreen md:hidden text-center btn-light-success bg-customLightGreen w-full md:w-auto min-w-[200px] md:mr-[21.5px] mr-0'>
                    Залишити заявку
                </a>
                <a href='#consultForm' class='btn btn-lg text-center btn-success w-full md:w-auto min-w-[200px] md:mr-[21.5px] mr-0'>
                    Почати 15-денну пробну версію
                </a>
                <span class='hidden md:block xl:block'>
                    <a href='#consultForm' class='btn btn-lg btn-light-success'>
                        Залишити заявку
                    </a>
                </span>
            </div>
      ");

require get_template_directory() . '/template-parts/common/heroSection.php';

